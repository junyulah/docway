module.exports = {
    template: ({title}) => `## ${title}`,
    content: {
        title: 'test'
    }
};
